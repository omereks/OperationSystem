#include <stdio.h>

int main()
{
    You shouldn't compile me!!!!
}