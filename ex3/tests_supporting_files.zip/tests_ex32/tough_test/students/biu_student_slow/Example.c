#include <unistd.h>
#include <stdio.h>

int main()
{
    printf("IM SLOWWWWW");
    sleep(8);
}
