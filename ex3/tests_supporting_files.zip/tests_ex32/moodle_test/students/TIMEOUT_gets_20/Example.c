#include <unistd.h>

int main()
{
    sleep(8);
}
