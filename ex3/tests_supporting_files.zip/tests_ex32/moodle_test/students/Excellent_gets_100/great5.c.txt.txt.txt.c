#include <stdio.h>

int main()
{
	int n1, n2;
	printf("Please enter two numbers\n");
	scanf ("%d %d",&n1, &n2);
	printf("%d", n1+n2);
}
